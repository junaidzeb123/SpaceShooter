#include"Addons.h"
#include"cstdlib"
#include"time.h"
class PowerUp:public Addons{
public:
PowerUp();
virtual void  move();
virtual Sprite& getSprite();
virtual string getType();

};
PowerUp::PowerUp(){
    srand(time(0));
    tex.loadFromFile("img/PNG/Power-ups/powerupRed_star.png");
    sprite.setTexture(tex);
    float x = rand()%880 + 200;
    sprite.setPosition(x,0);
    type = "Powerup";

}
string PowerUp:: getType(){
    return type;
}
void PowerUp:: move(){
    sprite.move(0,1);
}
Sprite& PowerUp:: getSprite(){
    return sprite;
}
