#include"Enemy.h"
// #include"Lightning.h"
class Dragon:public Enemy{
// Lightning*light;
    public:
        Dragon();
        void fire(int &no,int&nofobomb ,Enemy**&E,Bomb*&bomb);
};
Dragon::Dragon(){
        tex.loadFromFile("img/dragon1.png");
        sprite.setTexture(tex);
        sprite.setScale(1.3,1.3);
        
      
}
void Dragon:: fire(int &no,int&nofobomb ,Enemy**&E,Bomb*&bomb){
        	                 int i = 0;
                 if(nofobomb == 0){             // IF PRIVISIOULSY NO BOMB ON SCREEN    
                    bomb = new Bomb[ 3];
                     nofobomb += 3;
                 }
                 else {                         // IF PREVIOUSLY BOMB ARE TEHRE
                     Bomb* temp = bomb;
                     nofobomb += 3 ;
                     bomb = new Bomb[ nofobomb ];                     
                     for( ; i < nofobomb - 3 ; i++)
                        bomb[i] = temp[i];
                                      
                 } 
                
                int x[ 3];      // STORING THE CURRENT POSITION OF ALL ALPHA INVADERS
                int y[ 3 ];
                for(int i = 0 ; i < 3 ; i++){        // SETTING THE INITILA POSITION OF BOMB = TO POSITION OF ALPHA 
                    x[i] = E[ 4 ]->sprite.getPosition().x + 150;
                    y[i] = E[ 4 ]->sprite.getPosition().y + 280;
                    // cout<<"x ="<<x[i]<<" y= "<<y[i]<<endl;
                }
                
                for(int j = 0 ; i < nofobomb ; i++,j++){            //  J FOR NEW BOMB POSITON I FOR ALPHA
                    // bomb[i]  = Bomb(x[j],y[j]);
                    bomb[i].setPosition(x[j],y[j]);
                   
                }
                

 

}