/*
 * Beta.h
 *
 *  Created on: May 4, 2023
 *      Author: hp
 */
#include <SFML/Graphics.hpp>
#include<string.h>
#include "Invadors.h"

class Beta: public Invadors {
public:
	Beta();
	void movement(){}
	void fire(int &noofAlpha,int&noofbomb,Enemy**&E,Bomb*&bomb);
	~Beta();
};
void Beta::fire(int &nofBeta ,int&nofobomb,Enemy**&E,Bomb*&bomb){
	                 int i = 0;
                 if(nofobomb == 0){             // IF PRIVISIOULSY NO BOMB ON SCREEN    
                    bomb = new Bomb[ nofBeta ];
                     nofobomb += nofBeta ;
                 }
                 else {                         // IF PREVIOUSLY BOMB ARE TEHRE
                     Bomb* temp = bomb;
                     nofobomb += nofBeta ;
                     bomb = new Bomb[ nofobomb ];                     
                     for( ; i < nofobomb - nofBeta ; i++)
                        bomb[i] = temp[i];
                                      
                 } 
                
                int x[ nofBeta ];      // STORING THE CURRENT POSITION OF ALL ALPHA INVADERS
                int y[ nofBeta ];
                for(int i = 0 ; i < nofBeta ; i++){        // SETTING THE INITILA POSITION OF BOMB = TO POSITION OF ALPHA 
                    x[i] = E[ 1 ][i].sprite.getPosition().x;
                    y[i] = E[ 1 ][i].sprite.getPosition().y;
                    // cout<<"x ="<<x[i]<<" y= "<<y[i]<<endl;
                }
                
                for(int j = 0 ; i < nofobomb ; i++,j++){            //  J FOR NEW BOMB POSITON I FOR ALPHA
                    // bomb[i]  = Bomb(x[j],y[j]);
                    bomb[i].setPosition(x[j],y[j]);
                }
           
}

Beta::Beta() {
	type = 2;
	tex.loadFromFile("img/enemy_3.png");
	sprite.setTexture(tex);
	sprite.setPosition(x, y);
}

Beta::~Beta() {
	
}
