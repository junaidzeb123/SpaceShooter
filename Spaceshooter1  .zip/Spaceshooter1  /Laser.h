#include <SFML/Graphics.hpp>
using namespace sf;
class Laser{
public:
    Sprite sprite;
    Texture tex;
    Laser();
};


Laser::Laser(){
      tex.loadFromFile("img/PNG/Lasers/laserRed06.png");
    sprite.setTexture(tex);
     sprite.setScale(2,12.5);
    //  sprite.setOrigin()
}