#include"Addons.h"
class Lives:public Addons{
public:
Lives();
virtual void  move();
virtual Sprite& getSprite();
virtual string getType();

};
Lives::Lives(){
    srand(time(0));
    tex.loadFromFile("img/PNG/Power-ups/bolt_bronze.png");
    sprite.setTexture(tex);
    float x = rand()%880 + 200;
    sprite.setPosition(x,0);
    type = "Lives";

}
string Lives:: getType(){
    return type;
}
void Lives:: move(){
    sprite.move(0,1);
}
Sprite& Lives:: getSprite(){
    return sprite;
}
