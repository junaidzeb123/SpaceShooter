#ifndef ADDONS_H_
#define ADDONS_H_
#include <SFML/Graphics.hpp>
#include<string>
using namespace sf;
using namespace std;
class Addons{
protected:
    Sprite sprite;
    Texture tex;
    string type;
public:
    void setImage(string & path );
    void setPosition(float&x , float &y);
    float* getPosition();
   virtual Sprite &getSprite() = 0;
    virtual void move() = 0;
    virtual string getType() =  0;
};
void Addons::setImage(string & path ){
    tex.loadFromFile(path);
    sprite.setTexture(tex);
}  
void Addons::setPosition(float&x , float &y){
    sprite.setPosition(x , y);
}
float*  Addons::getPosition(){
    float* position = new float[2];
    position[0] = sprite.getPosition().x;
    position[1] = sprite.getPosition().y;
    return position;
}

#endif 