#include <SFML/Graphics.hpp>
#include<string.h>
using namespace sf;
class Bomb{
public:
Texture tex;
Sprite sprite;
float speed = 1.5;;
float x,y;
int direction;
double deltax;
double deltay;
Bomb&operator=(const Bomb& copy);
Bomb(int x, int y );
Bomb(const Bomb& copy);
Bomb(){
  deltax = 0 ;
  deltay  = 1;
    direction =  0;
    tex.loadFromFile("img/PNG/Lasers/laserRed08.png");
    // tex.loadFromFile("fire14.png");
sprite.setTexture(tex);
// sprite.setScale(1,1);
sprite.setScale(0.5,0.5);

}

void move( double s);
void setPosition(int x, int y);
};
//// = operator
Bomb& Bomb::operator=(const Bomb &copy){
      tex.loadFromFile("img/PNG/Lasers/laserRed08.png");
        //   tex.loadFromFile("img/PNG/Effects/fire17.png");
        sprite.setTexture(tex);
        sprite.setPosition(copy.sprite.getPosition());
        sprite.setScale(0.5,0.5);
        speed= copy.speed;
        direction = copy.direction;
        deltax = copy.deltax;
        deltay = copy.deltay;
        return*this;
}


////////////// CONSTRUCTORS ////////////
Bomb::Bomb(int x, int y ){
    this->x = x ;
    this->y = y ;
    direction = 0 ;
//  tex.loadFromFile("img/PNG/Effects/fire17.png");
  tex.loadFromFile("img/PNG/Lasers/laserRed08.png");
sprite.setTexture(tex);
// sprite.setPosition(x,y);
// sprite.setScale(0.7,0.7);
sprite.setScale(0.5,0.5);

}
///
 Bomb::Bomb(const Bomb& copy){
    //    tex.loadFromFile("img/PNG/Effects/fire14.png");
      tex.loadFromFile("img/PNG/Lasers/laserRed08.png");
        sprite.setTexture(tex);
        sprite.setScale(0.5,0.5);
        sprite.setPosition(copy.sprite.getPosition());
}
    ////  MOVEMENT OF BOMB  ///n
void Bomb::move(double s){
       speed = s;
        deltax= deltax* speed;
        deltay= deltay* speed;
        sprite.move(deltax , deltay);
        x = sprite.getPosition() . x ;
        y = sprite. getPosition(). y ;
        // cout<<"bomb Moveemtn x "<<x<<" y= "<<y<<endl;;
        // cout<<"directe = "<<direction<<endl;
}
///////// SETTING POSIION ///
void Bomb::setPosition(int x, int y){
    this->x = x ;
    this->y = y ;
    sprite.setPosition(x,y);
}
