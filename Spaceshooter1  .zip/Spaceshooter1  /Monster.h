#include"Enemy.h"

class Monster:public Enemy{
    int direction ;
    public:
    Monster();
    void movement();
     void fire(int &noofAlpha,int&noofbomb,Enemy**&E,Bomb*&bomb);
 
    
};
/// CONSTRUCTORS    //
Monster:: Monster(){
    laser = new Laser;
    direction = 1;
    tex.loadFromFile("img/monster1.png");
    sprite.setTexture(tex);
    sprite.setScale(0.5,0.5);
   speed = 1.5;
    // sprite.setOrigin(0,0);
}
////         MOVEMENT FUNTTION
 void Monster:: fire(int &noofAlpha,int&noofbomb,Enemy**&E,Bomb*&bomb){
     int x = sprite.getPosition().x + 150;
    int y = sprite.getPosition().y + 250;
    laser->sprite.setPosition(x,y);
    // cout<<"laer= "<<laser->sprite.getGlobalBounds().height<<endl;
    // cout<<"laer= "<<laser->sprite.getGlobalBounds().width<<endl;;
 }
///  ////////////////////
void Monster:: movement(){
    float delta_x ;
  
    if(sprite.getPosition().x <= 950 && direction == 1){
         delta_x = +1;
      
         if ( sprite.getPosition().x >= 670 ){
            direction = 0 ;
            
         }
    }
    if(direction == 0){      
         delta_x = -1;
         if( sprite.getPosition().x <= 168)
            direction =1 ;
    }
     delta_x*= speed;
    sprite.move(delta_x , 0);
}
///////////////////
