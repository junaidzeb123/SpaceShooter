#include"Addons.h"
class Fire:public Addons{
public:
    Fire();
     virtual void  move();
    virtual Sprite& getSprite();
    virtual string getType();
};
Fire::Fire(){
    srand(time(0));
    tex.loadFromFile("img/PNG/Power-ups/powerupYellow.png");
    sprite.setTexture(tex);
    float x = rand()%880 + 200;
    sprite.setPosition(x,0);
    type = "Fire";

}
string Fire:: getType(){
    return type;
}
void Fire:: move(){
    sprite.move(0,1);
}
Sprite& Fire:: getSprite(){
    return sprite;
}
