/*
 * Alpha.h
 *
 *  Created on: May 4, 2023
 *      Author: hp
 */


#include <SFML/Graphics.hpp>
#include<string.h>
#include "Invadors.h"

class Alpha: public Invadors {
public:
	Alpha();
	 void movement();
	 Alpha(const Alpha&copy){
			type = 1;
			tex.loadFromFile("img/enemy_2.png");
			sprite.setTexture(tex);
			sprite.setPosition(copy.sprite.getPosition());
			speed = copy.speed;
			cout<<"helloalphacopy const\n";
			
	 }
	Alpha& operator=(const Alpha&copy){
		tex.loadFromFile("img/enemy_2.png");
			sprite.setTexture(tex);
			sprite.setPosition(copy.sprite.getPosition());
			speed = copy.speed;
			cout<<"helloalphacopy const\n";
			return *this;
	}
	void fire(int &noofAlpha,int&noofbomb,Enemy**&E,Bomb*&bomb);
	~Alpha();
};
void Alpha:: fire(int &nofAlpha ,int&nofobomb,Enemy**&E,Bomb*&bomb){
               //  BOMB DRAPPING FOR ALPHA 
			   this->bomb = bomb;
                  int i = 0;
                 if(nofobomb == 0){             // IF PRIVISIOULSY NO BOMB ON SCREEN    
                    bomb = new Bomb[ nofAlpha ];
                     nofobomb += nofAlpha ;
                 }
                 else {                         // IF PREVIOUSLY BOMB ARE TEHRE
                     Bomb* temp = bomb;
                     nofobomb += nofAlpha ;
                     bomb = new Bomb[ nofobomb ];                     
                     for( ; i < nofobomb - nofAlpha ; i++)
                        bomb[i] = temp[i];
                              cout<<"hello\n";        
                 } 
                
                int x[ nofAlpha ];      // STORING THE CURRENT POSITION OF ALL ALPHA INVADERS
                int y[ nofAlpha ];
                for(int i = 0 ; i < nofAlpha ; i++){        // SETTING THE INITILA POSITION OF BOMB = TO POSITION OF ALPHA 
                    x[i] = E[ 0 ][i].sprite.getPosition().x;
                    y[i] = E[ 0 ][i].sprite.getPosition().y;

                    // cout<<"x1 ="<<x[i]<<" y1= "<<y[i]<<endl;
                }
                
                for(int j = 0 ; i < nofobomb ; i++,j++){            //  J FOR NEW BOMB POSITON I FOR ALPHA
                   
                    bomb[i].sprite.setPosition(x[j],y[j]);
                    // cout<<"x= "<<bomb[i].sprite.getPosition().x;
                    // cout<<" y= "<<bomb[i].sprite.getPosition().y<<endl;
                }                     
                 
        
         
}
Alpha::Alpha() {
	tex.loadFromFile("img/enemy_2.png");
	sprite.setTexture(tex);
	sprite.setPosition(x, y);


}
void Alpha::movement(){


}

Alpha::~Alpha() {
	
}
//



/////////////////////////////
