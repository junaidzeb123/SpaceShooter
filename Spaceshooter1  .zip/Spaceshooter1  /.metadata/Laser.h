#include <SFML/Graphics.hpp>
using namespace sf;
class Laser{
public:
    Sprite sprite;
    Texture tex;
    Laser(int x, int y);
    Laser();
};

Laser:: Laser(int x, int y){
    tex.loadFromFile("img/PNG/Lasers/laserRed01.png");
    sprite.setTexture(tex);
}
Laser::Laser(){
      tex.loadFromFile("img/PNG/Lasers/laserRed01.png");
    sprite.setTexture(tex);
}