#include <SFML/Graphics.hpp>
#include<SFML/Audio.hpp>
#include"menu.h"
#include <time.h>
#include <iostream>
#include "player.h"
#include"Alpha.h"
#include"Beta.h"
#include"Gamma.h"
#include"Monster.h"
#include"Dragons.h"
#include"PowerUP.h"
#include"Lives.h"
#include"Fire.h"
#include"Danger.h"
const char title[] = "OOP-Project, Spring-2023";
using namespace sf;
using namespace std;
class Game
{
public:
    sf::Font font1;
    sf::Text text1;
    Sprite background; // Game background sprite
    Texture bg_texture;
    Player *p; 
    Enemy **E;  //for enemies
    Bullet* b;  // bullets
    Bomb* bomb; // for bomb
    Bomb* Monsterbomb;
    Bomb* DragonBomb;
    Menu m;
    Addons* addons;
    int bdirection; // to control the direction of bullet according to the direction of spaceship
    int noOfBullets;    
    int nofAlpha; // alpha, beta ,gamma
    int nofBeta ; 
    int noofGamma;  
    int nofmonster;
    int nofDragons;
    int noOfMonsterBomb;
    int noOfDragonBomb;
    int nofobomb;    
    bool isDragon;
    bool isMonsters;
    bool isAlphaBomb;
    bool isBetaBomb;
    bool isGammaBomb;
    bool ismonsterLaser;
    bool isAddons;
    bool isPowerUp;
    bool isAvailAddons;
    bool isFire;
    int level;
    int phase;
    long int score;
     string s;
     float bombspeed;

  Music music;
     Game();    ///CONSTRUCTORS
    bool  start_game(int z);         // THE ACTUAL FUNTION WHICH STARTS THE GAME
    void playercontrol();       // CONTROLLING MOVEMENT OF PLAYER
    void DisplayingMenu(RenderWindow&); // MENU IS DISPLAYING HERE
    void DragonControl(RenderWindow&,float&DragonTimer,float&DragonBombTimer,float&monsterTimer); // ALL DRAGONS CONTROL
    void MonsterControl(RenderWindow&,float&MonsterTime,float&MonsterBombTime,float &DragonTimer );    // ALL MONSTER CONTROL
    void InvadersControl(RenderWindow&window,float&alphaTimer,float&betaTimer, float& gammaTimer );// INVADER
    void collisionDetection(RenderWindow&window);// COLLIOSN CHECKIN
    void PlayerFire(RenderWindow & window,float&bulletTimer);// FIRING
    void manageAddons(RenderWindow&windos,float&AddonsTimer, float&PowerUpTimer);
    void PauseScreen(RenderWindow&windo);
    void levelcontrol(RenderWindow&Window);
    ~Game();
    void   Restart();

}; 
Game::Game()
    {
    
        b = nullptr;
        noOfBullets = 0 ;
        bdirection = 0 ;        
        
        E = new Enemy*[5];
        nofmonster = 0 ;
        nofDragons = 0 ;
        nofAlpha = 0 ;
        nofBeta = 0 ;
        noofGamma = 0 ;
        noOfMonsterBomb = 0 ;
        bomb = nullptr;
        Monsterbomb = nullptr;
        DragonBomb = nullptr;
        addons = nullptr;
        noOfDragonBomb = 0 ;
        nofobomb = 0 ;
        bg_texture.loadFromFile("img/background1.png");
        background.setTexture(bg_texture);
        // background.setScale(3.2, 1);
        background.setScale(0.817,0.7);               
        isAlphaBomb  = 0;
        isBetaBomb = 0;
        isGammaBomb = 0;
        isDragon = 0 ;
        isMonsters = false;
        ismonsterLaser = 0;
        isAddons =  0;
        isPowerUp = 0;
        isAvailAddons = 0;
         isFire = 0 ;
         score = 0;
         phase = 0;
          string s = "\0";
        p = new Player("img/player_ship.png",addons,b);
          font1.loadFromFile("Font/HF-Skate-Sonic.ttf");    
         text1.setFont(font1);
    }
 bool Game:: start_game(int z)
    {       

 

 music.openFromFile("music/Clown.wav");
 music.setVolume(80);
 	music.play();
music.setLoop(true);
        srand(time(0));
        RenderWindow window(VideoMode(980, 780), title);
        window.setFramerateLimit(60);
  
        if(z == 0)
        DisplayingMenu(window);
        Clock clock;
        float timer = 0;
        float bulletTimer = 0;
        float EnemyTimer = 0;
        float alphaTimer = 0 ;   
        float betaTimer = 0 ;
        float gammaTimer = 0 ;
        float monsterTimer = 0 ;
        float monsterBombTimer = 0 ;
        float DragonTimer = 0 ;
        float DragonBombTimer = 0 ;   
        float AddonsTimer = 0; 
        float PowerUpTimer = 0 ;
        Texture frame1tex;
        Sprite frame1;
        frame1tex.loadFromFile("img/border.jpg");
        frame1.setTexture(frame1tex);
        frame1.setScale(0.35,0.6);
        sf::Text text2,text3,text4,text5,text6;
        level = 1;
        text2.setFont(font1);
        text3.setFont(font1);
        text4.setFont(font1);
        text5.setFont(font1);
        text6.setFont(font1);
        while (window.isOpen()){  
;
        
            float time = clock.getElapsedTime().asSeconds();
            clock.restart();
            timer += time;
            bulletTimer += time;
            EnemyTimer += time;
            alphaTimer +=time ; 
            betaTimer +=time ;
            gammaTimer +=time;
            monsterTimer += time;
            monsterBombTimer += time;
            DragonBombTimer += time;
            DragonTimer += time;
            AddonsTimer+=time;
            PowerUpTimer+=time;
            text2.setString("LIVES: "+to_string(p->CH));
            text3.setString("LEVEL: "+to_string(level));
            text4.setString("SCORE: "+to_string(score));
            text6.setString("PHASE: "+to_string(phase));
            // setPrecision(2);
            string t1 = to_string(timer);
            string t2;
            for(int i = 0 ; t1[i] !='.'; i++){
                    t2+=t1[i];
            }
            text5.setString("TIME: "+t2 );
            text5.setPosition(25,50);
            text4.setPosition(25,150);
            text2.setPosition(25,250);
            text6.setPosition(25,350);
            text3.setPosition(25,450);
           
           
            
            Event e;
            while (window.pollEvent(e))
            {
                if (e.type == Event::Closed) // If cross/close is clicked/pressed
                    window.close();          // close the game
            }   
             
            if ((Keyboard::isKeyPressed(Keyboard::Space)))
                PauseScreen(window);    // calling pause screen function
            window.clear(Color::Black); // clears the screen    
            window.draw(background);    // setting background
            // window.draw(frame1);
            window.draw(text2);
            window.draw(text3);
            window.draw(text4);
            window.draw(text5);
            window.draw(text6);
             playercontrol();    
            window.draw(p->sprite); // setting player on screen
        if(EnemyTimer >= 0.5){
            InvadersControl(window,alphaTimer,betaTimer,gammaTimer);

        }
            DragonControl(window,DragonTimer,DragonBombTimer,monsterTimer);
            MonsterControl(window,monsterTimer,monsterBombTimer,DragonTimer);
            collisionDetection(window);
            PlayerFire(window,bulletTimer);
            levelcontrol(window);
            manageAddons(window,AddonsTimer,PowerUpTimer);
          
            // manageAddons(window,AddonsTimer,PowerUpTimer);
           
 

        if(p->CH <=0){
            // window.close();
           if( m.GameOver(window))
            return 1;
            // goto jump;
            // Restart();
        }
        //    cout<<"alpha= "<<nofAlpha<<endl;
        // cout<<"beta= "<<nofBeta<<endl;
        // cout<<"gamma= "<<noofGamma<<endl;
        window.display();            
        }
    
        return 0;
}
void Game:: Restart(){
   
       Game* g = new Game;
    // g->start_game();
    int i = 0 ;
    while(g->start_game(i) == 1){
       
            delete g;
            g = new Game;
            i++;
          

    }




}
void Game::PlayerFire(RenderWindow & window,float&bulletTimer){
              
           
            if (Keyboard::isKeyPressed(Keyboard::Enter) && bulletTimer >= 0.1){ 
          
                    if(isPowerUp){
                        int k = 5;
                        for(int i = 0 ;  i < 7 ; i ++){
                         p->fire(noOfBullets,k ,bulletTimer); 
                              k++;
                        }
                  }
                  if(!isPowerUp){
                  p->fire(noOfBullets,bdirection ,bulletTimer);  
                  }



                //    if(isFire){
                        
                //  }
               
            }
            ///   DELETION OF BULLETS IF OUT OF SCREEN
for(int i = 0 ; i < noOfBullets; i++){
	if(b[i].sprite.getPosition().y < -52 || b[i].sprite.getPosition().y > 760 || b[i].sprite.getPosition().x > 950 || b[i].sprite.getPosition().x < 200){
		Bullet*temp = b;
		noOfBullets--;
		b = new Bullet[noOfBullets];
		bool flag = false;
		for(int j = 0 ; j < noOfBullets; j++){			
			if(j==i){
				flag = true;
				continue;
			}
			if(!flag){
			b[j] = temp[j];
			}
			else {
			b[j-1] = temp[j];
			}
		}
		delete[]temp;	
	}
	
}
for(int i = 0 ; i < noOfBullets ;i++){
    window.draw(b[i].sprite);
    b[i].move();
}

}
void Game::playercontrol(){

      if ((Keyboard::isKeyPressed(Keyboard::Up)) && (Keyboard::isKeyPressed(Keyboard::Right))){  
                p->move("k",bdirection);    
      }
       else if  ((Keyboard::isKeyPressed(Keyboard::Up)) && (Keyboard::isKeyPressed(Keyboard::Left)))    // If down key is pressed
                p->move("j",bdirection);                            // player will move downwards
           else if  ((Keyboard::isKeyPressed(Keyboard::Down)) && (Keyboard::isKeyPressed(Keyboard::Right)))     // If down key is pressed
                p->move("n",bdirection);                            // player will move downwards
          else  if ((Keyboard::isKeyPressed(Keyboard::Down)) && (Keyboard::isKeyPressed(Keyboard::Left)))  // If downed
                p->move("m",bdirection);  
        else  if (Keyboard::isKeyPressed(Keyboard::Left))  // If left key is pressed
                p->move("l",bdirection);                            // Player will move to left
            else if (Keyboard::isKeyPressed(Keyboard::Right)) // If right key is pressed
                p->move("r",bdirection);                            // player will move to right
           else if (Keyboard::isKeyPressed(Keyboard::Up))    // If up key is pressed
                p->move("u",bdirection);                            // playet will move upwards
           else if (Keyboard::isKeyPressed(Keyboard::Down))  // If down key is pressed
                p->move("d",bdirection);                            // player will move downwards
                                    // player will move downwards
           
            else{
                p->sprite.setTexture(p->tex[0]);
                bdirection = 0 ;
            }     
}
void Game::DisplayingMenu(RenderWindow & window){
      while (window.isOpen()){
            m.display_menu(window);
             Event e;
            while (window.pollEvent(e)){
                if (e.type == Event::Closed) {// If cross/close is clicked/pressed
                    window.close();   
                }
              
            }
            float x = Mouse::getPosition(window).x;
            float y = Mouse::getPosition(window).y;
            if ((x > 279 && x < 475 && y > 122 && y < 210) ){
               
                if(Mouse::isButtonPressed(Mouse::Left)){
                    break;
            }
            }
            else if(x >= 271 && x <= 440 && y > 260 && y < 335 ){
                if(Mouse::isButtonPressed(Mouse::Left))
                m.displaye_help(window);
            }
            else if(x >= 196 && x <= 593 && y > 397 && y < 465 ){
             
            }

            else if(x >= 276 && x<= 430 && y > 516 && y < 593 ){
            
            }
           
         

        }
       
}
void Game:: DragonControl(RenderWindow&window,float&DragonTimer,float&DragonBombTimer,float&monsterTimer  ){

             if(DragonTimer >= 1000000 && isDragon == 0 && isMonsters == 0){
                //   int a=  rand() % 1000;
                //   if(a != 560 )   
                //         return;
                isDragon = 1;
                E[4] = new Dragon;
                DragonTimer = 0;
                E[4]->sprite.setPosition(400,50);
           }
            if(isDragon){
                
             Text t1;
            t1.setFont(font1);
            t1.setString("Dragon: ");     
            t1.setPosition(830,100); 
            window.draw(t1);
            string str1 = to_string(30 - DragonTimer);   
            string str2;
            for(int i = 0 ; str1[i-2] != '.'; i++)
                str2+=str1[i];
            t1.setString(str2);
            t1.setPosition(830,150);
            window.draw(t1);
               window.draw(E[4]->sprite);
               
                 if(DragonTimer >= 90){
                    isDragon = 0;
                    DragonTimer = 0;
                   monsterTimer = 0;
                    score+=50;
                 }
            }
            if(isDragon == 1&& DragonBombTimer >= 1.5){
            // cout<<"noofDragonbomn= "<<noOfDragonBomb<<endl;
            int a = 1;
            E[4]->fire(a,noOfDragonBomb,E,DragonBomb);
                DragonBombTimer = 0;
            float xdiff = E[4]->sprite.getPosition().x +110 - p->sprite.getPosition().x;

            float ydiff = E[4]->sprite.getPosition().y + 210 - p->sprite.getPosition().y;
            if(xdiff >= 0 && xdiff <= 160 ){
               DragonBomb[noOfDragonBomb -3 ].deltax = -0.6;
               DragonBomb[noOfDragonBomb -2 ].deltax = -0.3;
               DragonBomb[noOfDragonBomb -1 ].deltax = 0;
            
            }
            else if(xdiff >= 160  ){
              DragonBomb[noOfDragonBomb -3 ].deltax = -0.3;
               DragonBomb[noOfDragonBomb -2 ].deltax = -0.6;
               DragonBomb[noOfDragonBomb -1 ].deltax = -1;
            }
            else if(xdiff <= 0 && xdiff >= -230){
                 
               DragonBomb[noOfDragonBomb -3 ].deltax = 0.6;
               DragonBomb[noOfDragonBomb -2 ].deltax = 0.3;
               DragonBomb[noOfDragonBomb -1 ].deltax = 0;
            }
            else if(xdiff <= -230){
                DragonBomb[noOfDragonBomb -3 ].deltax = 1;
               DragonBomb[noOfDragonBomb -2 ].deltax = 0.6;
               DragonBomb[noOfDragonBomb -1 ].deltax = 0.3;
            }
            else{
                 DragonBomb[noOfDragonBomb -3 ].deltax = -0.3;
               DragonBomb[noOfDragonBomb -2 ].deltax = 0.3;
               DragonBomb[noOfDragonBomb -1 ].deltax = 0;
            }
       
            }
          for(int i = 0 ; i < noOfDragonBomb ;i++){
            window.draw(DragonBomb[i].sprite);
            DragonBomb[i].sprite.move(DragonBomb[i].deltax,1);
      
          
            }
        for(int i = 0 ; i < noOfDragonBomb; i++){
	if(DragonBomb[i].sprite.getPosition().y < -52 || DragonBomb[i].sprite.getPosition().y > 760 || DragonBomb[i].sprite.getPosition().x > 955 || DragonBomb[i].sprite.getPosition().x < 200){
		Bomb*temp = DragonBomb;
		noOfDragonBomb--;
    
		DragonBomb = new Bomb[noOfDragonBomb];
		bool flag = false;
		for(int j = 0 ; j < noOfDragonBomb; j++){			
			if(j==i){
				flag = true;
				continue;
			}
			if(!flag)
			DragonBomb[j] = temp[j];
			else 
			DragonBomb[j-1] = temp[j];
		}
		delete[]temp;
		temp = nullptr;		
	}
}



 }
void Game::MonsterControl(RenderWindow&window,float&monsterTimer,float&monsterBombTimer ,float &DragonTimer){
               ////     MONSTER CONTROLS bomb    ///
        if(monsterTimer >= 0 && isMonsters ==0 && isDragon == 0){
            int a=  rand() % 1000;
            if(a != 560 )   // monstr will came if and only when a = 560
                return;
            isMonsters = 1;
            E[3] = new Monster;
            E[3]->sprite.setPosition(200,110);
            monsterTimer = 0;

        }
        if(isMonsters){  
            Text t1;
            t1.setFont(font1);
            t1.setString("Monster: ");     
            t1.setPosition(830,100); 
            window.draw(t1);
            string str1 = to_string(25 - monsterTimer);   
            string str2;
            for(int i = 0 ; str1[i-2] != '.'; i++)
                str2+=str1[i];
            t1.setString(str2);
            t1.setPosition(830,150);
            window.draw(t1);
            window.draw(E[3]->sprite);
            E[3]->movement();
            if(monsterBombTimer >= 2){
               E[3]->fire(nofmonster,noOfMonsterBomb,E,Monsterbomb);
               window.draw(E[3]->laser->sprite);
               ismonsterLaser = 1;
                if(monsterBombTimer >4){
                    monsterBombTimer = 0;
                    ismonsterLaser = 0;
                }

            }          
         }

 
     ///////////// dogin mosnter 
            if(isMonsters){
                if(monsterTimer >= 500){
                    isMonsters = 0 ;
                    score+=40;
                    delete E[3];
                    monsterTimer = 0;
                     DragonTimer = 0;
                    
                }
            }
   
 }
void Game::InvadersControl(RenderWindow&window,float&alphaTimer,float&betaTimer, float& gammaTimer ){
      
for(int i = 0 ; i < nofAlpha; i++){
    if(E[0][i].sprite.getPosition().y < -52 || E[0][i].sprite.getPosition().y > 760 || E[0][i].sprite.getPosition().x > 950 || E[0][i].sprite.getPosition().x < 200){
        Enemy*temp = E[0];
		nofAlpha--;
		E[0] = new Alpha[nofAlpha];
		bool flag = false;
		for(int j = 0 ; j < nofAlpha; j++){			
			if(j==i){
				flag = true;
				continue;
			}
			if(!flag)
			E[0][j] = temp[j];
			else 
			E[0][j-1] = temp[j];
		}
		delete[]temp;
		temp = nullptr;		
    }
}
     
for(int i = 0 ; i < nofBeta; i++){
    if(E[1][i].sprite.getPosition().y < -52 || E[1][i].sprite.getPosition().y > 760 || E[1][i].sprite.getPosition().x > 950 || E[1][i].sprite.getPosition().x < 200){
        Enemy*temp = E[1];
		nofBeta--;
		E[1] = new Beta[nofBeta];
		bool flag = false;
		for(int j = 0 ; j < nofBeta; j++){			
			if(j==i){
				flag = true;
				continue;
			}
			if(!flag)
			E[1][j] = temp[j];
			else 
			E[1][j-1] = temp[j];
		}
		delete[]temp;
		temp = nullptr;		


    }

}
      
for(int i = 0 ; i < noofGamma; i++){
    if(E[2][i].sprite.getPosition().y < -52 || E[2][i].sprite.getPosition().y > 760 || E[2][i].sprite.getPosition().x > 950 || E[2][i].sprite.getPosition().x < 200){
        Enemy*temp = E[2];
		noofGamma--;
		E[2] = new Gamma[noofGamma];
		bool flag = false;
		for(int j = 0 ; j < noofGamma; j++){			
			if(j==i){
				flag = true;
				continue;
			}
			if(!flag)
			E[2][j] = temp[j];
			else 
			E[2][j-1] = temp[j];
		}
		delete[]temp;
		temp = nullptr;		
    }
}

    int k;


    if(isMonsters == 0 && isDragon == 0)
     for(int j = 0 ; j < 3 ;j++){        // DRAWING INVADERS
                if( j == 0 )
                   k = nofAlpha;
                else if(j == 1)
                    k = nofBeta;
                else if(j == 2)
                    k = noofGamma;
                for(int i = 0 ; i < k; i++){
                    window.draw(E[j][i].sprite);
                }
            }



    int a;

if(isMonsters == 0 && isDragon ==  0){
if(alphaTimer >= 7 && nofAlpha != 0 ){ 
        E[0]->fire(nofAlpha , nofobomb,E,bomb );
        alphaTimer = 0 ; 

        // isAlphaBomb = 0;
}            
if(betaTimer >= 3 && nofBeta != 0 ){          //  BOMB DRAPPING FOR ALPHA 
        E[1]->fire(nofBeta , nofobomb,E,bomb );               
        betaTimer = 0 ;
        // isBetaBomb = 0;
}

if(gammaTimer >=11 && noofGamma != 0 ){          //  BOMB DRAPPING FOR ALPHA 
        E[2]->fire(noofGamma,nofobomb,E,bomb);
        gammaTimer= 0 ;
        // betaTimer = 0;
        // alphaTimer = 0;
        isGammaBomb = 0 ;
}
}

for(int i = 0 ; i < nofobomb; i++){
	if(bomb[i].sprite.getPosition().x < -52 || bomb[i].sprite.getPosition().y > 760 || bomb[i].sprite.getPosition().x > 955 || bomb[i].sprite.getPosition().x < 200){
		Bomb*temp = bomb;
		nofobomb--;
		bomb = new Bomb[nofobomb];
		bool flag = false;
		for(int j = 0 ; j < nofobomb; j++){			
			if(j==i){
				flag = true;
				continue;
			}
			if(!flag)
			bomb[j] = temp[j];
			else 
			bomb[j-1] = temp[j];
		}
		delete[]temp;
		temp = nullptr;		
	}
}

for(int i  = 0 ; i < nofobomb; i++){	
			window.draw(bomb[i].sprite);
			bomb[i].move(bombspeed);	
}
 
        
 }
void Game::collisionDetection(RenderWindow&window){
            if(isMonsters == 0 && isDragon == 0){
            for(int i = 0 ; i < 3 ; i++){   
                int limit;    
                     if(i == 0 )
                         limit = nofAlpha;
                    else if(i == 1 )
                         limit = nofBeta;
                    else if(i == 2)
                         limit = noofGamma;

                for(int j = 0 ; j < limit ; j++){
                    if( (p->x >= ( E[i][j].sprite.getPosition().x - 30 ) && p->x <=( E[i][j].sprite.getPosition().x + 30 ) )  &&   (p->y >= ( E[i][j].sprite.getPosition().y - 30 ) && p->y<=( E[i][j].sprite.getPosition().y + 30 ) ) ){
                        p->CH--;
                        p->sprite.setPosition(340,700);
                        if(nofobomb != 0){
                        delete[]bomb;
                        bomb = nullptr;
                          nofobomb = 0;
                        }
                      
                        break;
                    }
                   
                }
            }       
           

            // DETROWING ALPAH INAVDERS WITH BULLETS
           
for(int i = 0 ; i < nofAlpha ; i++){
    bool check = 0;
    for(int j = 0 ;j < noOfBullets; j++){
            if( (b[j].x >= ( E[0][i].sprite.getPosition().x - 30 ) && b[j].x <=( E[0][i].sprite.getPosition().x + 30 ) )  &&   (b[j].y >= ( E[0][i].sprite.getPosition().y - 30 ) && b[j].y<=(E[0][i].sprite.getPosition().y + 30 ) ) ){
                    // DISTROWING ENEMIES/
                {   // these brackets are just to make my work easy so that i can copy paste my other code her
                Enemy*temp = E[0];
                nofAlpha--;
                if(nofAlpha ==0){
                    delete[]E[0];
                    break;
                }
                E[0] = new Alpha[nofAlpha];
                bool flag = false;
                for(int k = 0 ; k < nofAlpha; k++){
                    if(k == i){                                       
                        flag = true;
                        continue;
                    }
                    if(!flag)
                    E[0][k] = temp[k];
                    else 
                    E[0][k-1] = temp[k];
                }

                delete[]temp;
                    temp = nullptr;
                    score += level*10;
                }
             if(isFire== 0&& isPowerUp == 0)   {
                    Bullet*temp = b;
                    noOfBullets--;
                    b = new Bullet[noOfBullets];
                    bool flag = false;
                    for(int  k = 0 ; k < noOfBullets; k++){			
                    if(k==j){
                    flag = true;
                    continue;
                    }
                    if(!flag){
                    b[k] = temp[k];
                    }
                    else {
                    b[k-1] = temp[k];
                    }
                    }
                    delete[]temp;	
                }

//////
    
            }
   
    }

        
}            // // DISTROWING BETA INAVDERS WITH BULLETS
           for(int i = 0 ; i < nofBeta ; i++){
                bool check = 0;
                for(int j = 0 ;j < noOfBullets; j++){
                      if( (b[j].x >= ( E[1][i].sprite.getPosition().x - 30 ) && b[j].x <=( E[1][i].sprite.getPosition().x + 30 ) )  &&   (b[j].y >= ( E[1][i].sprite.getPosition().y - 30 ) && b[j].y<=(E[1][i].sprite.getPosition().y + 30 ) ) ){
                                // DISTROWING ENEMIES//
                                {
                                Enemy*temp = E[1];
                                nofBeta--;
                                E[1] = new Beta[nofBeta];
                                bool flag = false;
                                for(int k = 0 ; k < nofBeta; k++){
                                    if(k == i){                                       
                                        flag = true;
                                        continue;
                                    }
                                    if(!flag)
                                    E[1][k] = temp[k];
                                    else 
                                    E[1][k-1] = temp[k];
                              }
                                

                                delete[]temp;
                                temp = nullptr;
                                score += level*20;
                                }
                         
                        if(isFire== 0&& isPowerUp == 0)    {
                           {
                    Bullet*temp = b;
                    noOfBullets--;
                    b = new Bullet[noOfBullets];
                    bool flag = false;
                    for(int  k = 0 ; k < noOfBullets; k++){			
                    if(k==j){
                    flag = true;
                    continue;
                    }
                    if(!flag){
                    b[k] = temp[k];
                    }
                    else {
                    b[k-1] = temp[k];
                    }
                    }
                    delete[]temp;	
                }

              }
                               //////
                      }
                }
              
                    
            }


            //  DISTROWING GAMMA INVAERS
    for(int i = 0 ; i < noofGamma ; i++){
                bool check = 0;
                for(int j = 0 ;j < noOfBullets; j++){
                      if( (b[j].x >= ( E[2][i].sprite.getPosition().x - 30 ) && b[j].x <=( E[2][i].sprite.getPosition().x + 30 ) )  &&   (b[j].y >= ( E[2][i].sprite.getPosition().y - 30 ) && b[j].y<=(E[2][i].sprite.getPosition().y + 30 ) ) ){
                                // DISTROWING ENEMIES//{
                                    {
                                Enemy*temp = E[2];
                                noofGamma--;
                                E[2] = new Gamma[noofGamma];
                                bool flag = false;
                                for(int k = 0 ; k < noofGamma; k++){
                                    if(k == i){                                       
                                        flag = true;
                                        continue;
                                    }
                                    if(!flag)
                                    E[2][k] = temp[k];
                                    else 
                                    E[2][k-1] = temp[k];
                              }
                                
                                delete[]temp;
                                 temp = nullptr;
                                 score += level*30;
                                    }

                               //////
                          if(isFire==0 && isPowerUp == 0){
                                                 {
                    Bullet*temp = b;
                    noOfBullets--;
                    b = new Bullet[noOfBullets];
                    bool flag = false;
                    for(int  k = 0 ; k < noOfBullets; k++){			
                    if(k==j){
                    flag = true;
                    continue;
                    }
                    if(!flag){
                    b[k] = temp[k];
                    }
                    else {
                    b[k-1] = temp[k];
                    }
                    }
                    delete[]temp;	
                }
                                }
                      }
                }
              
                    
            }


             } 
      //  CHECK FOR BOMB HITTING SHIP OR NOT
      if(isMonsters == 0 && isDragon == 0){
           for(int i = 0 ;  i < nofobomb; i ++){            
               if( (p->x >= ( bomb[i].sprite.getPosition().x - 30 ) && p->x <=( bomb[i].sprite.getPosition().x + 30 ) )  &&   (p->y >= ( bomb[i].sprite.getPosition().y - 30 ) && p->y<=(bomb[i].sprite.getPosition().y + 30 ) ) ){
                      p->CH--;
                    p->sprite.setPosition(340,700);
                     if(nofobomb != 0){
                        delete[]bomb;
                        bomb = nullptr;
                        nofobomb = 0;
                        }
                      break;
               }
                    // cout<<"b.x="<<bomb[i].x<<" b.y="<<bomb[i].y<<endl;
           }             
      }
 
 // DETECTION WITH LASER OF MONSTER
    if(isMonsters){
    float height =  E[3]->laser->sprite.getGlobalBounds().height;  
    float widht =  E[3]->laser->sprite.getGlobalBounds().width;  
    float laserx = E[3]->laser->sprite.getPosition().x;
    float lasery = E[3]->laser->sprite.getPosition().y;
    float px = p->sprite.getPosition().x;
    float py = p->sprite.getPosition().y; ;
    if(ismonsterLaser){
    if(py >= lasery && py <= lasery+height && (px >=laserx && px <= laserx+widht) ) {   // DETECTION WITH LASER 
           p->CH--;
           ismonsterLaser = 0;
        p->sprite.setPosition(340,700);
    
    }
    else if(py >= lasery && py <= lasery+height &&  (laserx>=px && laserx<=px+p->sprite.getGlobalBounds().width)){
        p->CH--;
        ismonsterLaser = 0 ;
        p->sprite.setPosition(340,700);
           
    }
    
         
    }
    // COLLISION DETECTION WITH MONSTER
    float height1 =  E[3]->sprite.getGlobalBounds().height;  
    float widht1 =  E[3]->sprite.getGlobalBounds().width;  
     float monsterx = E[3]->sprite.getPosition().x;
    float monstery = E[3]->sprite.getPosition().y;
    if(py >= monstery+30 && py <= monstery+height1 && px >=monsterx+150 && px <= monsterx+widht1) { // DETECTION WITH LASER 
        p->CH--;
        p->sprite.setPosition(340,700);
    }
     
    else if(py >= monstery+30 && py <= monstery+height1 && monsterx+150>=px && monsterx<=px+p->sprite.getGlobalBounds().width){
        p->CH--;
        p->sprite.setPosition(340,700);
    }

    }
    ///////////////// DRAGON BOMBS
        
           for(int i = 0 ;  i < noOfDragonBomb; i ++){            
               if( (p->x >= ( DragonBomb[i].sprite.getPosition().x - 30 ) && p->x <=( DragonBomb[i].sprite.getPosition().x + 30 ) )  &&   (p->y >= ( DragonBomb[i].sprite.getPosition().y - 30 ) && p->y<=(DragonBomb[i].sprite.getPosition().y + 30 ) ) ){
                      p->CH--;
                    p->sprite.setPosition(340,700);
                     if(noOfDragonBomb != 0){
                        delete[]DragonBomb;
                        DragonBomb = nullptr;
                        noOfDragonBomb= 0;
                        }
                      break;
               }
                  
           }             
      
 
         
}
void Game::manageAddons(RenderWindow&window,float&AddonsTimer,float&PowerUpTimer){
                        if(AddonsTimer >= 5 && isAddons == 0){
                int a = rand()%100;
                if(a == 10){        // PRODUCING RANDOMLY ADDONS EITEHR POWER,LIVES OR ELSE
                    int b = rand()% 5;
                    if(b == 1){
                        addons = new PowerUp;
                        isAddons = 1;
                        AddonsTimer = 0 ;
                    }
                    if(b == 2){
                        // addons = new Fire;
                        // isAddons = 1;
                        // AddonsTimer = 0 ;
                          addons = new PowerUp;
                        isAddons = 1;
                        AddonsTimer = 0 ;
                    }
                    if(b == 3){
                        // addons = new Danger;
                        // isAddons = 1;
                        // AddonsTimer = 0 ;
                          addons = new PowerUp;
                        isAddons = 1;
                        AddonsTimer = 0 ;
                    }
                    if(b == 4){
                        // addons = new Lives;
                        // isAddons = 1;
                        // AddonsTimer = 0 ;
                          addons = new PowerUp;
                        isAddons = 1;
                        AddonsTimer = 0 ;
                    }
                    
        }
    }
       
       
                   
                     if(isAddons){
                        text1.setString((addons->getType()));
                        text1.setPosition(850,0);
                        window.draw(text1);
            window.draw(addons->getSprite());
            addons->move();
            // float* ptr = addons->getPosition();
            if(addons->getSprite().getPosition().y >= 760){
                isAddons = 0;
                AddonsTimer = 0 ;
                delete addons;
                addons = nullptr;
            } 
        }
         if(isAddons){
     s =  p->availAddons(isAddons,isPowerUp,isAvailAddons, isFire,AddonsTimer);
    }

       
        if(isPowerUp == 1){
             text1.setString("POWER-UP");
            text1.setPosition(830,0);
            window.draw(text1);
            string str1 = to_string(5 - AddonsTimer);
            string str2;
            for(int i = 0 ; str1[i-3] !='.';i++ )
                str2+=str1[i];
            text1.setString(str2);
            text1.setPosition(830,50);
            window.draw(text1);
        }
        if(isFire == 1){
             text1.setString("FIRE");
            text1.setPosition(830,0);
            window.draw(text1);
            string str1 = to_string(5 - AddonsTimer);
            string str2;
            for(int i = 0 ; str1[i-3] !='.';i++ )
                str2+=str1[i];
            text1.setString(str2);
            text1.setPosition(830,50);
            window.draw(text1);
        }
        if(isAvailAddons == 1 && AddonsTimer>=5){
            isAddons = 0;
            AddonsTimer = 0 ;
            delete addons;
            isPowerUp = 0 ;
            isFire = 0 ;
            isAvailAddons = 0;
            addons = nullptr;
        }
   
   
       


}
void Game:: PauseScreen(RenderWindow&window){                
        while (window.isOpen()){
            Event e;
            while (window.pollEvent(e)){
                if (e.type == Event::Closed) // If cross/close is clicked/pressed
                    window.close();          // close the game
                    if(Keyboard::isKeyPressed(Keyboard::S)){
                        // window.close();
                        return ;     
                    }
            }    
            text1.setString("PRESS S TO RESUME");
            text1.setPosition(180,300);
            text1.setScale(2,2);
            window.draw(text1);
            window.display();
        }

}
void Game:: levelcontrol(RenderWindow&window){
if(level == 1)
    bombspeed = 1;
else if(level ==2)
    bombspeed = 1;
else if(level ==3)
    bombspeed = 1;
if(level == 1){
    
 if(isMonsters == 0 && isDragon == 0){    // IF NO MONSTER THEN THE INVADERS WILL FOR
        if(nofAlpha==0 && nofBeta==0 && noofGamma==0 && level== 1){        // PRODUCING ENEMY  
        phase++;
        if(phase > 3){
            
            phase = 0;
            level++;
            return ;           
        }
        noofGamma = 20 ;
        nofBeta = 9 ;
        nofAlpha = 10 ;
        E[0] = new Alpha[  nofAlpha];
        E[1] = new Beta[ nofBeta ];
        E[2] = new Gamma[ noofGamma ];
            int w = 250;
            int h = 50;
            // MAKING RECTANGEL WITH ALPHA INVADERS
        for(int i = 0 ; i < nofAlpha ; i++){
            if(i <=3){
                E[0][i].sprite.setPosition(w,h);
                w+=50;
            }
            else if(i <= 5){
                    w = 250;
                    h+=50;
                E[0][i].sprite.setPosition(w,h);
            }
            else if (i <= 8){
                w+=50;
                E[0][i].sprite.setPosition(w,h);
            }
            else if(i <10){
        //                    	w = 100;
                h-=50;
                    E[0][i].sprite.setPosition(w,h);
            }
        }
       
        // 	MAKING TRIANLGES WITH BEAT INVADERS
        h = 50; // settin h again 50
        w+=100;
        h+=150;
        for(int i = 0 ; i < nofBeta; i++){
                if(i == 0){
                    w+=150;
                    h-=150;
                    E[1][i].sprite.setPosition(w,h);
                }
                else if(i <=3){
                    h+=50;
                    w-=50;
                    E[1][i].sprite.setPosition(w,h);
                }
                else if(i <= 6){
                    w += 100;
                    E[1][i].sprite.setPosition(w,h);
                }
                else if(i < 10){
                    h-=50;
                    w-=50;
                    E[1][i].sprite.setPosition(w,h);
                }
               
        }
        // 	MAKING CROSS SHAPE WITH GAMMA INVADERS	//////////
        w = 250;
        h += 200;
        for(int i = 0 ; i < noofGamma-10; i++){
            if(i < 5){
                E[2][i].sprite.setPosition(w,h);
                w+=30;
                h+=30;
            }
            else if(i < 10){
                if(i == 5 ){
                    w-=150;
                    h-=30;
                }
                E[2][i].sprite.setPosition(w,h);
                w+=30;
                h-=30;
            }
        }
            w+=100;
        for(int i =noofGamma-10  ; i < noofGamma; i++){
            if(i < 15){
                E[2][i].sprite.setPosition(w,h);
                w+=30;
                h+=30;
            }
            else if(i < 20){
                if(i == 15 ){
                    w-=150;
                    h-=30;
                }
                E[2][i].sprite.setPosition(w,h);
                w+=30;
                h-=30;
            }
            }

        }

 
}
       ////  BOMB DRAPPING..............................
}   


if(level == 2 && nofAlpha == 0 && nofBeta == 0 && noofGamma == 0 && isMonsters == 0 && isDragon == 0){
 
    phase++;
    if(phase > 3){
        phase = 0;
        level++;
        return ;           
    }
       noofGamma = 8;
    nofAlpha = 8 ;
    nofBeta = 9;
    E[0] = new Alpha[  nofAlpha];
    E[1] = new Beta[ nofBeta ];
    E[2] = new Gamma[ noofGamma ];
    //circle with alpha
    E[0][0].sprite.setPosition(240,130);
    E[0][1].sprite.setPosition(500,130);
    E[0][2].sprite.setPosition(370,10);
    E[0][3].sprite.setPosition(465,55);
    E[0][4].sprite.setPosition(275,45);
    E[0][5].sprite.setPosition(275,205);
    E[0][6].sprite.setPosition(465,205);
    E[0][7].sprite.setPosition(370,260);
    // diamont with Beta
      E[1][0].sprite.setPosition(540,180);
      E[1][1].sprite.setPosition(660,180);
      E[1][2].sprite.setPosition(780,180);
      E[1][3].sprite.setPosition(660,10);
      E[1][4].sprite.setPosition(660,350);
      E[1][5].sprite.setPosition(600,105);
      E[1][6].sprite.setPosition(720,105);
      E[1][7].sprite.setPosition(600,255);
      E[1][8].sprite.setPosition(720,255);
    // hearts with gamma
         E[2][0].sprite.setPosition(350,310);
        E[2][1].sprite.setPosition(430,330); 
        E[2][2].sprite.setPosition(510,310);
        E[2][3].sprite.setPosition(330,380);
        E[2][4].sprite.setPosition(530,380);
        E[2][5].sprite.setPosition(370,430);
        E[2][6].sprite.setPosition(490,430);
        E[2][7].sprite.setPosition(430,460);
}
    


 if(level == 3 && nofAlpha == 0 && nofBeta == 0 && noofGamma == 0 && isMonsters == 0 && isDragon == 0) {
    phase++;
    if(phase >3){
        m.GameOver(window);
    }
    if(phase == 1){
        nofAlpha = 12;
        E[0] = new Alpha[nofAlpha];
      E[0][0].sprite.setPosition(300,50);
      E[0][1].sprite.setPosition(350,50);
      E[0][2].sprite.setPosition(400,50);
      E[0][3].sprite.setPosition(450,50);
      E[0][4].sprite.setPosition(300,100);
      E[0][5].sprite.setPosition(300,150);
      E[0][6].sprite.setPosition(350,150);
      E[0][7].sprite.setPosition(400,150);
      E[0][8].sprite.setPosition(450,150);
      E[0][9].sprite.setPosition(450,100);
      E[0][10].sprite.setPosition(350,100);
      E[0][11].sprite.setPosition(400,100);
       nofBeta = 14;
         E[1] = new Beta[nofBeta];
      E[1][0].sprite.setPosition(540,180);
      E[1][1].sprite.setPosition(660,180);
      E[1][2].sprite.setPosition(780,180);
      E[1][3].sprite.setPosition(660,10);
      E[1][4].sprite.setPosition(660,350);
      E[1][5].sprite.setPosition(600,105);
      E[1][6].sprite.setPosition(720,105);
      E[1][7].sprite.setPosition(600,255);
      E[1][8].sprite.setPosition(720,255);   
       E[1][9].sprite.setPosition(600,180);
       E[1][10].sprite.setPosition(720,180);
         E[1][11].sprite.setPosition(660,95);
       E[1][12].sprite.setPosition(660,265);
       E[1][13].sprite.setPosition(720,255);
    }    


     if(phase == 2){
        nofBeta = 16;
        //FILLED TRIANGELES WITH BETA
        E[1] = new Beta[nofBeta];
        E[1][0].sprite.setPosition(650,50);
        E[1][1].sprite.setPosition(600,100);
        E[1][2].sprite.setPosition(700,100);
         E[1][3].sprite.setPosition(650,100);
        E[1][4].sprite.setPosition(550,150);
       E[1][5].sprite.setPosition(600,150);
          E[1][6].sprite.setPosition(650,150);
          E[1][7].sprite.setPosition(700,150);
           E[1][8].sprite.setPosition(750,150);
        E[1][9].sprite.setPosition(500,200);
        E[1][10].sprite.setPosition(600,200);
        E[1][11].sprite.setPosition(700,200);
        E[1][12].sprite.setPosition(800,200);
          E[1][13].sprite.setPosition(550,200);
          E[1][14].sprite.setPosition(650,200);
          E[1][15].sprite.setPosition(750,200);
      ////////////////////////////////////
        noofGamma = 20;
    E[2] = new Gamma[ noofGamma ];
//     //circle with alpha
        E[2][0].sprite.setPosition(370,10);
        E[2][1].sprite.setPosition(275,55);
         E[2][2].sprite.setPosition(370,45);
        E[2][3].sprite.setPosition(465,55);
        E[2][4].sprite.setPosition(240,135);
         E[2][5].sprite.setPosition(370,130); 
        E[2][6].sprite.setPosition(500,135);  
             E[2][7].sprite.setPosition(305,130); 
    E[2][8].sprite.setPosition(435,130); 
        E[2][9].sprite.setPosition(275,205);
        E[2][10].sprite.setPosition(370,205);
        E[2][11].sprite.setPosition(465,205);
        E[2][12].sprite.setPosition(370,260);
    E[2][13].sprite.setPosition(370,85); 
    E[2][14].sprite.setPosition(370,167 ); 
    }


if(phase == 3){
    noofGamma = 14;
    E[2] = new Gamma[noofGamma];
     E[2][0].sprite.setPosition(420,80);
      E[2][1].sprite.setPosition(385,110);
     E[2][2].sprite.setPosition(350,140);
     E[2][3].sprite.setPosition(315,170);
     E[2][4].sprite.setPosition(280,200);
     E[2][5].sprite.setPosition(245,230);
     E[2][6].sprite.setPosition(215,260);
    E[2][7].sprite.setPosition(215,80);
    E[2][8].sprite.setPosition(245,110);
    E[2][9].sprite.setPosition(280,140);
    E[2][10].sprite.setPosition(315,170);
    E[2][11].sprite.setPosition(350,200);
    E[2][12].sprite.setPosition(385,230);
    E[2][13].sprite.setPosition(420,260);
    ////////
        // hearts with gamma
        nofAlpha = 24;
        E[0] = new Alpha[nofAlpha];
         E[0][0].sprite.setPosition(550,60);
        E[0][1].sprite.setPosition(630,80); 
        E[0][2].sprite.setPosition(710,60);
        E[0][3].sprite.setPosition(530,130);
        E[0][4].sprite.setPosition(730,130);
         E[0][5].sprite.setPosition(580,130);
      E[0][6].sprite.setPosition(630,130);
      E[0][7].sprite.setPosition(680,130);
        E[0][8].sprite.setPosition(570,180);
        E[0][9].sprite.setPosition(690,180);
        E[0][10].sprite.setPosition(630,180);
        E[0][11].sprite.setPosition(630,230);
/////////
         E[0][12].sprite.setPosition(400,290);
        E[0][13].sprite.setPosition(480,310); 
        E[0][14].sprite.setPosition(560,290);
        E[0][15].sprite.setPosition(380,360);
        E[0][16].sprite.setPosition(580,360);
         E[0][17].sprite.setPosition(430,360);
      E[0][18].sprite.setPosition(480,360);
      E[0][19].sprite.setPosition(530,360);
        E[0][20].sprite.setPosition(420,410);
        E[0][21].sprite.setPosition(540,410);
        E[0][22].sprite.setPosition(480,410);
        E[0][23].sprite.setPosition(480,470);
       ///
     
      
 
}

 }  


}
Game::~Game(){
    if(p!= nullptr)
    delete p;
    if(E!= nullptr)
    delete[]E;
    if(b!= nullptr)
    delete[] b;
    if(bomb != nullptr)
    delete[]bomb;
    if(Monsterbomb!= nullptr)
    delete[]Monsterbomb;
    if(DragonBomb != nullptr)
    delete[]DragonBomb;
}
