/*
 * Invadors.h
 *
 *  Created on: May 4, 2023
 *      Author: hp
 */
#ifndef INVADORS_H_
#define INVADORS_H_
#include <SFML/Graphics.hpp>
#include<string.h>
#include "Enemy.h"
// #include"Bomb.h"
using namespace sf;
class Invadors: public Enemy {
public:
	Invadors();
	virtual void movement() = 0;
	~Invadors();
};


Invadors::Invadors() {
	
	sprite.setScale(0.3,0.3);
}
Invadors::~Invadors() {
	// TODO Auto-generated destructor stub
}



#endif /* A_H_ */