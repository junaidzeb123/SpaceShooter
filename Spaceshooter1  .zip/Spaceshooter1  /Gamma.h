/*
 * Gamma.h
 *
 *  Created on: May 4, 2023
 *      Author: hp
 */
#include <SFML/Graphics.hpp>
#include<string.h>
#include "Invadors.h"

class Gamma: public Invadors {
public:
	Gamma();
	void movement(){}
	void fire(int &noofGamma,int&nofobomb ,Enemy**&E,Bomb*&bomb);
	~Gamma();
};

Gamma::Gamma() {
	type = 3;
	tex.loadFromFile("img/enemy_1.png");
	sprite.setTexture(tex);
	sprite.setPosition(x, y);
	

}
void Gamma::fire(int &noofGamma,int&nofobomb ,Enemy**&E,Bomb*&bomb){
                int i = 0;
        if(nofobomb == 0){             // IF PRIVISIOULSY NO BOMB ON SCREEN    
        bomb = new Bomb[ noofGamma ];
            nofobomb += noofGamma ;
        }
        else {                         // IF PREVIOUSLY BOMB ARE TEHRE
            Bomb* temp = bomb;
            nofobomb += noofGamma ;
            bomb = new Bomb[ nofobomb ];                     
            for( ; i < nofobomb - noofGamma ; i++)
            bomb[i] = temp[i];
                            
        } 
    
    int x[ noofGamma ];      // STORING THE CURRENT POSITION OF ALL ALPHA INVADERS
    int y[ noofGamma];
    for(int i = 0 ; i < noofGamma ; i++){        // SETTING THE INITILA POSITION OF BOMB = TO POSITION OF ALPHA 
        x[i] = E[ 2 ][i].sprite.getPosition().x;
        y[i] = E[ 2 ][i].sprite.getPosition().y;
        // cout<<"x ="<<x[i]<<" y= "<<y[i]<<endl;
    }
    
    for(int j = 0 ; i < nofobomb ; i++,j++){            //  J FOR NEW BOMB POSITON I FOR ALPHA
        // bomb[i]  = Bomb();
        bomb[i].setPosition(x[j],y[j]);
    }

        

}

Gamma::~Gamma() {
	// TODO Auto-generated destructor stub
}
