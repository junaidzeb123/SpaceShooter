 

#ifndef ENEMY_H_
#define ENEMY_H_
#include <SFML/Graphics.hpp>
#include <time.h>
#include<cstdlib>
#include<iostream>
#include"Bomb.h"
#include"Laser.h"
using namespace std;
using namespace sf;
class Enemy{
    public:
    Texture tex;
    Sprite sprite;
    float speed=0.5;
     int type ;
     int x, y;
     Laser* laser;
     Bomb* bomb;
   virtual void fire(int &nofAlpha ,int&nofobomb,Enemy**&E,Bomb*&bomb) = 0;
   Enemy& operator=(Enemy&copy){
       tex = copy.tex;      
       if(copy.type == 1)
       tex.loadFromFile("img/enemy_2.png");
       else if(copy.type == 2)
            tex.loadFromFile("img/enemy_3.png");
       else if(copy.type == 3)
            tex.loadFromFile("img/enemy_1.png");
        sprite.setTexture(tex);
        speed = copy.speed;
        sprite.setPosition(copy.sprite.getPosition());
        type = copy.type;
        return *this;
   }
virtual void movement() {}
Enemy(){
     bomb = nullptr;
}
};

#endif /* A_H_ */