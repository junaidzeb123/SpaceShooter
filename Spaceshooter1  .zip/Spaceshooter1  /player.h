#include <SFML/Graphics.hpp>
#include<string.h>
#include"Bullet.h"
#include<iostream>
#include"Addons.h"
using namespace std;
// Monsterbomb;
using namespace sf;
class Player{
public:
Texture tex[5];
Sprite sprite;
float speed=4;
int MaxH;
int CH;
int x,y;
bool isAddons;
Bullet*&b;
// Bullet*&b;
Addons *&addons;
void fire(int & noOfBullets,int bdirection,float&bulletTimer);
Player(std::string png_path,Addons*&addons,Bullet*&b);
void  move(std::string s,int &bdirectin );
string availAddons(bool& isAddons,bool&isPowerUp,bool&isavailAddons,bool&isFire,float&addonsTimer);

};
string  Player::availAddons(bool&isAddons,bool& isPowerUp,bool&isavailAddons,bool&isFire,float&addonsTimer){
	float height1 =  addons->getSprite().getGlobalBounds().height;  
	float widht1 =  addons->getSprite().getGlobalBounds().width;  
	float addonsx = addons->getSprite().getPosition().x;
	float addonsy = addons->getSprite().getPosition().y;
	float px = sprite.getPosition().x;
	float py = sprite.getPosition().y;
	string type;
	if(isAddons)
	if(py >= addonsy && py <= addonsy+height1 ){    // DETECTION WITH LASER 
		if(px >= addonsx && px <= addonsx+widht1){
			if(addons->getType() == "Lives"  && CH< MaxH){
				CH++;
				type = "Life";
			}
			if(addons->getType() == "Danger"){
				CH--;
				type = "dANGER";;

				
			}
			if(addons->getType() == "Powerup"){
					isPowerUp = 1;
					type = "POWER-UP";
			}
			if(addons->getType() == "Fire" ){
				type = "FIRE";
				isFire = 1;
			}
			delete addons;
			addons = nullptr;
			isavailAddons = 1;
			addonsTimer =  0;
			isAddons = 0 ;
		}
	}
	if(isAddons)
	if(py >=addonsy && py <= addonsy+height1 )
	if(addonsx >=px && addonsx<=px+sprite.getGlobalBounds().width){
				if(addons->getType() == "Lives"  && CH<MaxH){
					CH++;		
			}
			if(addons->getType() == "Danger" ){
					CH--;
			}
			if(addons->getType() == "Powerup"){
					
					isPowerUp = 1;
						type = "POWER-UP";

			}
			if(addons->getType() == "Fire"){
				
				isFire = 1;
				type = "FIRE";
			}
		delete addons;
			addons = nullptr;
			isAddons = 0 ;
			addonsTimer =  0;
			isavailAddons = 1;
	}

	return type;
}

void Player:: fire( int & noOfBullets,int bdirection,float&bulletTimer){
	 			this->b = b;
				 noOfBullets ++;
                int x = this->sprite.getPosition().x;
                int y = this->sprite.getPosition().y;
                if(bdirection ==0){
                x += 37;
                y += -36;
                }
                else if(bdirection ==1){
                    x+=70;
                    // x-=50;
                }
                else if(bdirection ==2){
                    // x=70;
                }
                else if(bdirection ==3){
                    x+=70;
                    y+=70;
                    
                }
                else if(bdirection ==4){
                     x-=10;
                    y+=70;
                    
                }
               else {
					 x += 37;
                y += -36;
			   }
                Bullet* temp = b;
                b = new Bullet[noOfBullets];
                int i = 0;
                for( ; i < noOfBullets-1 ; i++){
                    b[i]  = temp[i];
                }
                    b[i] = Bullet(x,y,bdirection);	
                    delete[]temp;
                  bulletTimer = 0;
}

Player::Player(std::string png_path,Addons*&addons,Bullet*&b):addons(addons),b(b){
isAddons = 0 ;
MaxH = 3; 
CH = MaxH;
tex[0].loadFromFile(png_path);
tex[1].loadFromFile("img/player2.png");
tex[2].loadFromFile("img/player3.png");
tex[3].loadFromFile("img/player4.png");
tex[4].loadFromFile("img/player5.png");
sprite.setTexture(tex[0]);
x=340;y=700;
sprite.setPosition(x,y);
sprite.setScale(0.75,0.75);
}

void Player:: move(std::string s,int &bdirectin){
float delta_x=0,delta_y=0;
if(s=="l"){
	delta_x = -1;
	sprite.setTexture(tex[0]);
	bdirectin = 0 ;
	
}
else if(s=="r"){
	delta_x = +1;
	sprite.setTexture(tex[0]);
	bdirectin = 0 ;
}
if(s=="u"){
	delta_y=-1;
	sprite.setTexture(tex[0]);
	bdirectin = 0 ;
}
else if(s=="d"){
	delta_y=1;
	sprite.setTexture(tex[0]);
	bdirectin = 0 ;
}
else if(s=="k"){
	delta_y =-1;
	delta_x =1;	
	sprite.setTexture(tex[1]);
	bdirectin = 1; 
}
else if(s=="j"){
	
	delta_y =-1;
	delta_x =-1;
	sprite.setTexture(tex[2]);
	bdirectin = 2 ;
}
else if(s=="n"){
	
	delta_y =+1;
	delta_x =+1;
	bdirectin = 3;
	sprite.setTexture(tex[3]);
}
else if(s=="m"){
	delta_y =+1;
	delta_x =-1;
	sprite.setTexture(tex[4]);
	bdirectin = 4;
}

delta_x*=speed;
delta_y*=speed;
// if()

int x = sprite.getPosition().x;
int y= sprite.getPosition().y;
if(x < 200){
	sprite.setPosition(950,y);
}
else if(x > 950){
	sprite.setPosition(200,y);
}
if(y < -52){
	sprite.setPosition(x,760);
}
else if(y > 760){
	sprite.setPosition(x,-52);
}
sprite.move(delta_x, delta_y);
this->x = sprite.getPosition().x;
this->y = sprite.getPosition().y;
// cout<<"p.x="<<p.x<<" p.y="<<p.y<<endl;
}

