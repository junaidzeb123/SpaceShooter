// #include "menu.h"
#include"game.h"
#include<iostream>
int main()
{
    
    Game g ;
    g.Restart();
    return 0;
}
