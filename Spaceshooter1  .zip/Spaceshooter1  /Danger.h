#include"Addons.h"
class Danger:public Addons{
public:
    Danger();
        virtual void  move();
       virtual Sprite& getSprite();
       virtual string getType();
};
Danger::Danger(){
    srand(time(0));
    tex.loadFromFile("img/PNG/Power-ups/things_gold.png");
    sprite.setTexture(tex);
    float x = rand()%880 + 200;
    sprite.setPosition(x,0);
    type = "Danger";

}
string Danger:: getType(){
    return type;
}
void Danger:: move(){
    sprite.move(0,1);
}
Sprite& Danger:: getSprite(){
    return sprite;
}
