#include <SFML/Graphics.hpp>
#include<string.h>
#include<iostream>
using namespace std;
using namespace sf;
class Bullet{
public:
Texture tex;
Sprite sprite;
float speed = 7;
float x,y;
 int bdirection;
 int pdiection ;
 Bullet&operator=(const Bullet&copy){
      tex.loadFromFile("img/PNG/Lasers/laserRed01.png");
    sprite.setTexture(tex);
    speed = copy.speed;
    sprite.setPosition(copy.sprite.getPosition());  
    bdirection = copy.bdirection;
    return *this;

 }
 Bullet (const Bullet& copy){
   tex.loadFromFile("img/PNG/Lasers/laserRed01.png");
    sprite.setTexture(tex);
    speed = copy.speed;
    sprite.setPosition(copy.sprite.getPosition());
    bdirection = copy.bdirection;
    sprite.setScale(1,1);
 }
Bullet(){
// tex.loadFromFile("img/PNG/Lasers/laserRed01.png");
// sprite.setTexture(tex);
x = 140 ; y= 140;
}
Bullet(int x, int y,int b,int pdirection = 0):bdirection(b),pdiection(pdirection){
  tex.loadFromFile("img/PNG/Lasers/laserRed01.png");
sprite.setTexture(tex);
this->x = x;
this->y = y;
static int x1 = 0 ;
sprite.setPosition(this->x, this->y);
sprite.setScale(1,1);
}
void move(){
  float delat_y =-1.5;
  float delta_x = 0;
  if(bdirection == 0){
    delat_y =-1.5;
    delta_x = 0;
  }
  else if(bdirection == 1){
    delat_y =-1.5;
    delta_x = 1.5;
  }
  else if(bdirection == 2){
    delat_y =-1.5;
    delta_x = -1.5;
  }
  else if(bdirection == 3){
    delat_y =1.5;
    delta_x =1.5;
  }
  else if(bdirection == 4){
    delat_y =1.5;       
    delta_x =-1.5;
  }
  // if(pdiection == 0)
  {
   if(bdirection == 5){
     delat_y =-1.5;
    delta_x = 0;
      // cout<<"hello-11"<<endl;
  }
  else if(bdirection == 6){
     delat_y =-1.5;
    delta_x = 0.3;
  }
  else if(bdirection == 7){
     delat_y =-1.5;
    delta_x = 0.6;
      // cout<<"hello-7"<<endl;
  }
  else if(bdirection == 8){
     delat_y =-1.5;
    delta_x = 0.9;
      // cout<<"hello-8"<<endl;
  }
  else if(bdirection == 9){
     delat_y =-1.5;
    delta_x = -0.3;
      // cout<<"hello-9"<<endl;
  }
  else if(bdirection == 10){
     delat_y =-1.5;
    delta_x = -0.6;
      // cout<<"hello10"<<endl;
  }
  else if(bdirection == 11){
     delat_y =-1.5;
    delta_x = -0.9;
    // cout<<"hello-11"<<endl;
  }
  }

  // if(pdiection == 1){
  //  if(bdirection == 5){
  //    delat_y =-1.5;
  //   delta_x = 0 + 1.5;
  //     // cout<<"hello-11"<<endl;
  // }
  // else if(bdirection == 6){
  //    delat_y =-1.5;
  //   delta_x = 0.3 + 1.5;
  // }
  // else if(bdirection == 7){
  //    delat_y =-1.5;
  //   delta_x = 0.6;
  //     // cout<<"hello-7"<<endl;
  // }
  // else if(bdirection == 8){
  //    delat_y =-1.5;
  //   delta_x = 0.9 + 1.5;
  //     // cout<<"hello-8"<<endl;
  // }
  // else if(bdirection == 9){
  //    delat_y =-1.5;
  //   delta_x = -0.3 + 1.5;
  //     // cout<<"hello-9"<<endl;
  // }
  // else if(bdirection == 10){
  //    delat_y =-1.5;
  //   delta_x = -0.6 + 1.5;
  //     // cout<<"hello10"<<endl;
  // }
  // else if(bdirection == 11){
  //    delat_y =-1.5;
  //   delta_x = -0.9 + 1.5;
  //   // cout<<"hello-11"<<endl;
  // }
  // }


  delat_y *=speed;
  delta_x*= speed;
  
   sprite.move(delta_x,delat_y);
  y = sprite.getPosition().y;
  x = sprite.getPosition().x;
}

};
